<footer class="footer">

   <section class="grid">

      <div class="box">
         <h3>tautan langsung</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> shop</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> contact</a>
      </div>

      <div class="box">
         <h3>tautan tambahan</h3>
         <a href="user_login.php"> <i class="fas fa-angle-right"></i> login</a>
         <a href="user_register.php"> <i class="fas fa-angle-right"></i> register</a>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> keranjang</a>
         <a href="orders.php"> <i class="fas fa-angle-right"></i> orders</a>
      </div>

      <div class="box">
         <h3>Tentang Kami</h3>
         <a href="https://api.whatsapp.com/send/?phone=6287749121822&text&type=phone_number&app_absent=0" target="_blank"><i class="fab fa-whatsapp"></i> Whatsapp</a>
         <a href="https://www.instagram.com/sabanaadventurejombor/" target="_blank"><i class="fab fa-instagram"></i>instagram</a>
         <a href="https://mail.google.com/mail/u/0/?view=cm&tf=1&fs=1&to=verydw08@gmail.com" target="_blank"><i class="fas fa-envelope"></i>email</a>
         <a href="https://maps.app.goo.gl/USHuDwKUAq61tJCw5" target="_blank"><i class="fas fa-map-marker-alt"></i> Lokasi </a>
      </div>

   </section>

</footer>